require "byebug"

class Employee
    attr_accessor :salary, :title, :boss, :name
    def initialize(name, title, salary, boss)
        @name = name
        @title = title
        @salary = salary
        @boss = boss
    end

    def bonus(multiplier)

        bonus = (@salary) * multiplier

    end

end

class Manager < Employee

    
    attr_accessor :dependent_employees, :salary
    def initialize(name, title, salary, boss, dependent_employees)
        super(name, title, salary, boss)
      
        @dependent_employees = dependent_employees
    end

    def bonus(multiplier)
        total * multiplier
    end

    def total
        sub_employees_total = 0
        @dependent_employees.each do |dep| 
            if dep.is_a? Manager 
                sub_employees_total += dep.salary + dep.total
            else
                sub_employees_total += dep.salary  
            end  
     
        end
        
        sub_employees_total
    end

end

dave = Employee.new("Dave", "TA", 10000, "Darren")
shawna = Employee.new("Shawna", "TA", 12000, "Darren")
darren = Manager.new("Dave", "TA Manager", 78000, "Ned", [dave, shawna])
ned = Manager.new("Dave", "TA", 1000000, nil, [darren])

p darren.dependent_employees
p ned.bonus(5)
p darren.bonus(4)
p dave.bonus(3)
