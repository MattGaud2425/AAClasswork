def stock_picker(stock_prices)
    #outputs the most profitable pair of days on which to first buy the 
    #stock and then sell the stock
    # low_day = 0
    # low = stock_prices[0]
    # high_day = 0
    # high = stock_prices[0]
    # stock_prices.each.with_index do |price, i|

    # end
    # return []

    arr = []
    target = 0 
    stock_prices.each_with_index do |x, idx1|
        stock_prices.each_with_index do |y, idx2|
            if idx2 > idx1 
                arr = [idx1, idx2] if y - x > target
                target = y - x
            end
        end
    end
    return arr
end