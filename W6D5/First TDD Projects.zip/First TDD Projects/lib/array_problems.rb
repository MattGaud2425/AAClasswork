class Array 

    def uniq
        # arr = []
        # self.each {|ele| arr << ele if !arr.include?(ele)}
        # return arr
        self.uniq!
    end

    def two_sum
        arr = []
        self.each_with_index do |x, idx1|
            self.each_with_index do |y, idx2|
                if idx2 > idx1 
                    arr << [idx1, idx2] if x + y == 0 
                end
            end
        end
        return arr
    end

end