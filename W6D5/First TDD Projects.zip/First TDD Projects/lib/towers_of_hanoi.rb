class TowersOfHanoi
    attr_reader :arr1, :arr2, :arr3

    SORTED_ARRAY = [5,4,3,2,1]

    def initialize(arr1) 
        @arr1 = arr1
        @arr2 = []
        @arr3 = []        
    end

    def display 
        p @arr1, @arr2, @arr3 
    end

    def prompt
        display
        puts "please choose an array: 1, 2, 3"
        input = gets.chomp.to_i
        case input 
        when 1
            selected1 = arr1
        when 2
            selected1 = arr2
        when 3
            selected1 = arr3
        end

        puts "selected = #{selected1}"
        puts "Choose Array to PLACE on"
        input2 = gets.chomp.to_i
        case input2
        when 1
            selected2 = arr1
        when 2
            selected2 = arr2
        when 3
            selected2 = arr3
        end

        puts "selected Array to Place on = #{selected2}"
        move(selected1, selected2)
    end


    def move(array1, array2)
        raise "cannot move from empty stack" if array1.empty?
        ele = array1.pop()
        if array2.empty?
            array2.push(ele)
        elsif array2.last > ele
            array2.push(ele)
        else
            array1.push(ele)
        end
        won?
    end

    def won? 
        @arr3 == SORTED_ARRAY
        puts "You Won!!!"
    end
end

if __FILE__ == $PROGRAM_NAME 
    game = TowersOfHanoi.new([5,4,3,2,1])
    until game.won? 
        game.prompt
    end

end