require 'array_problems'

describe Array do

    let(:array1) { [1, 2, 1, 3, 3] }
    let(:array2) { [-1, 0, 2, -2, 1] }

    it "#uniq" do
        expect(array1.uniq).to eq([1, 2, 3])
    end

    it "#two_sum" do
        expect(array2.two_sum).to eq([[0, 4], [2, 3]])
    end 

end