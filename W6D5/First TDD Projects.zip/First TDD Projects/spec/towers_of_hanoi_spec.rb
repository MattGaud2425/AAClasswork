require 'towers_of_hanoi'

describe "TowersOfHanoi" do
    subject(:game) { TowersOfHanoi.new(arr1) }
    # before { expect(:game).to receive(:move).with(1, anything, /bar/) }

    let(:arr1) {[5, 4, 3, 2, 1]}

    describe "#initialize" do
        it "should keep three arrays which represent the piles of discs" do
            expect(game.arr1.class).to be(Array)
            expect(game.arr2.class).to be(Array)
            expect(game.arr3.class).to be(Array)
        end
        it "should set the first array to be beginning tower" do
            expect(game.arr1).to eq(arr1)
        end
        it "should set the other two arrays to be empty towers" do
            expect(game.arr2).to eq([])
            expect(game.arr3).to eq([])
        end
    end

    describe "#move" do        
        it "allows moving to a blank space" do
            expect { game.move([1,2,3], []) }.not_to raise_error
        end
    
        it "allows moving onto a larger disk" do
            expect { game.move([2, 1], [3]) }.not_to raise_error
        end

        it "does not allow moving from an empty stack" do
            expect { game.move([], [3]) }.to raise_error("cannot move from empty stack")
        end
    end

    describe "#won" do
        let(:arr3) {[5, 4, 3, 2, 1]}
        it "should have a properly stacked array" do
            expect(TowersOfHanoi.won?).to eq(true) if game.arr3 == arr1
        end
    end

end