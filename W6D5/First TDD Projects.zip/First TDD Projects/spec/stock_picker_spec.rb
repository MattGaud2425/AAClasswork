require "stock_picker"

describe "#stock_picker" do
    
    let (:stock_price) { [50, 75, 100] }

    it "should buy and sell stock on the correct days" do
        expect(stock_picker(stock_price)).to eq([0, 2])
    end

end